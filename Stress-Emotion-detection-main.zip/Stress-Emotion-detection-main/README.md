#Stress-Emotion-detection-SAARTHI

### download FER2013 dataset
- from below link and put in data folder under your project directory
- https://www.kaggle.com/msambare/fer2013

### All the Packages need to be installed

From the deep learning CNN Model the emotion detected by images dataset.
From the emotion detection we can classify that which kind of stress the person have.
 Stress detection techniques and technologies have the potential to provide valuable insights into individuals' mental and physical well-being. They can assist in early identification of stress-related disorders, facilitate effective stress management interventions, and contribute to overall improved health outcomes.
Reasons why stress detection is conducted:
Early identification and intervention
Personal well-being and self-awareness
Health management
Performance optimization
Public health and policy


Category of stress level using emotion detection:

Low Stress Levels :
Happy
Neutral

Moderate Stress Levels :
Surprised 
Sad

High Stress Levels :
Disgusted
Fearful

BY using vGG-16 and RESNET we find the accuracy.


